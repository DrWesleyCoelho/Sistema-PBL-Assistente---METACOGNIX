from fastapi import APIRouter
from app.core.state_machine import PBLStateMachine

router = APIRouter()
session = PBLStateMachine()

@router.get("/step")
def get_step():
    return {"current_step": session.current_step}

@router.post("/next")
def next_step():
    return {"next_step": session.next_step()}
