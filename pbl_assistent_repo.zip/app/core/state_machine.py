class PBLStateMachine:
    def __init__(self):
        self.steps = [
            "leitura_do_problema",
            "termos_desconhecidos",
            "hipoteses",
            "estruturacao",
            "objetivos_aprendizado",
            "estudo_individual",
            "rediscussao"
        ]
        self.current_step = self.steps[0]

    def next_step(self):
        idx = self.steps.index(self.current_step)
        if idx < len(self.steps) - 1:
            self.current_step = self.steps[idx + 1]
        return self.current_step
