# PBL Assistent

Sistema educacional médico baseado em PBL com IA.

## Stack
- FastAPI (backend)
- PostgreSQL + pgvector
- Flutter (frontend)
- Firebase Auth

## Como rodar

### Backend
```
pip install -r requirements.txt
uvicorn app.main:app --reload
```

### Banco
```
docker-compose up
```
